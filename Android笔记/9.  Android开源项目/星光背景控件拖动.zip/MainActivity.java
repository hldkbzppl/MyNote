package com.example.viewpagerdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

public class MainActivity extends Activity {

	private int width;//屏幕宽度
	private int height;//屏幕高度
	private float ration_big = 3; //大布局放大倍数
	private float ration_small = 1.5f; //小布局放大倍数 
	
	private ImageView image; //大布局
	private RelativeLayout layout; //小布局

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		

		image = (ImageView) findViewById(R.id.touch_layout);
		layout = (RelativeLayout) findViewById(R.id.r_layout2);
		
		image.post(new Runnable() {
			@SuppressLint("NewApi")
			@Override
			public void run() {
				DisplayMetrics metric = new DisplayMetrics();
				getWindowManager().getDefaultDisplay().getMetrics(metric);
				width = metric.widthPixels;
				height = metric.heightPixels;
				
				RelativeLayout.LayoutParams relaL = (RelativeLayout.LayoutParams) image.getLayoutParams();
				relaL.width = (int) (width * ration_big);
				relaL.height = (int) (height * ration_big);
				image.setX((int) (width / 2 + -width * ration_big / 2));
				image.setY((int) (height / 2 + -height * ration_big / 2));
				image.setLayoutParams(relaL);

				RelativeLayout.LayoutParams relaL2 = (LayoutParams) layout.getLayoutParams();
				relaL2.width = (int) (width * ration_small);
				relaL2.height = (int) (height * ration_small);
				layout.setX((int) (width / 2 + -width * ration_small / 2));
				layout.setY((int) (height / 2 + -height * ration_small / 2));
				layout.setLayoutParams(relaL2);
			}
		});

		image.setOnTouchListener(new OnTouchListener() {
			private int x;
			private int y;
			private int min_x;
			private int min_y;
			
			private int event_x;
			private int event_y;

			@SuppressLint("NewApi")
			@Override
			public boolean onTouch(View v, MotionEvent event) {

				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					event_x = (int) event.getRawX();
					event_y = (int) event.getRawY();
					
					x = (int) image.getX();
					y = (int) image.getY();
					
					min_x = (int) layout.getX();
					min_y = (int) layout.getY();
					
					break;
				case MotionEvent.ACTION_MOVE:
					//大布局移动事件
					int pianyiliang_x = (int) ( x + event.getRawX() - event_x);
					int pianyiliang_y = (int) ( y + event.getRawY() - event_y);
					//小布局移动事件
					int min_pianyiliang_x = (int) ( min_x + (event.getRawX() - event_x) / ration_big * ration_small);
					int min_pianyiliang_y = (int) ( min_y + (event.getRawY() - event_y) / ration_big * ration_small);
					
					if (pianyiliang_x > 0) {
						image.setX(0);
					} else if (pianyiliang_x < -width * (ration_big-1)) {
						image.setX(-width * (ration_big-1));
					} else {
						image.setX(pianyiliang_x);
						layout.setX(min_pianyiliang_x);
					}

					if (pianyiliang_y > 0) {
						image.setY(0);
						return true;
					} else if (pianyiliang_y < -height * (ration_big-1)) {
						image.setY(-height * (ration_big-1));
						return true;
					} else {
						image.setY(pianyiliang_y);
						layout.setY(min_pianyiliang_y);
					}
				}
				return true;
			}
		});
	}
}
